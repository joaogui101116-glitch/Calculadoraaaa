package com.calculadora.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.MimeTypeMap;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";

    private WebView web;
    private File sharedDir;
    private boolean pageReady = false;
    private String pendingJson = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF14272E);
        getWindow().setNavigationBarColor(0xFF14272E);

        sharedDir = new File(getCacheDir(), "shared");
        sharedDir.mkdirs();

        web = new WebView(this);
        web.setBackgroundColor(0xFF14272E);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/shared/", new WebViewAssetLoader.InternalStoragePathHandler(this, sharedDir))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    // nenhum app para abrir o link
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                if (pendingJson != null) {
                    deliver(pendingJson);
                    pendingJson = null;
                }
            }
        });

        web.loadUrl("https://" + HOST + "/assets/index.html");
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) {
            return;
        }
        final String type = intent.getType() == null ? "" : intent.getType();
        final String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        final String subject = intent.getStringExtra(Intent.EXTRA_SUBJECT);
        @SuppressWarnings("deprecation")
        final Uri stream = intent.getParcelableExtra(Intent.EXTRA_STREAM);

        new Thread(() -> {
            try {
                JSONObject o = new JSONObject();
                o.put("text", text == null ? "" : text);
                o.put("title", subject == null ? "" : subject);
                if (stream != null) {
                    String mt = getContentResolver().getType(stream);
                    if (mt == null) {
                        mt = type;
                    }
                    String url = copyToShared(stream, mt);
                    if (url != null) {
                        o.put("mediaUrl", url);
                        o.put("mediaType", mt);
                    }
                }
                final String json = o.toString();
                runOnUiThread(() -> {
                    if (pageReady) {
                        deliver(json);
                    } else {
                        pendingJson = json;
                    }
                });
            } catch (Exception e) {
                // se falhar, o app abre normalmente
            }
        }).start();
    }

    private String copyToShared(Uri uri, String mime) throws Exception {
        File[] old = sharedDir.listFiles();
        if (old != null) {
            for (File f : old) {
                f.delete();
            }
        }
        String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
        if (ext == null) {
            ext = (mime != null && mime.startsWith("image/")) ? "jpg" : "mp4";
        }
        String name = "midia_" + System.currentTimeMillis() + "." + ext;
        File out = new File(sharedDir, name);
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream os = new FileOutputStream(out)) {
            if (in == null) {
                return null;
            }
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) {
                os.write(buf, 0, n);
            }
        }
        return "https://" + HOST + "/shared/" + name;
    }

    private void deliver(String json) {
        web.evaluateJavascript("window.onNativeShare && window.onNativeShare(" + json + ");", null);
    }
}
