'use strict';

/* =====================================================================
   CALCULADORA + MASCOTE
   - A calculadora é real (sem eval): analisador próprio de expressões.
   - Recebe links e vídeos pelo "Compartilhar" do Android (Web Share Target,
     tratado em sw.js). Só funciona depois de instalar o app a partir de um
     endereço https.
   - O mascote NÃO analisa o vídeo. Ele escolhe frases divertidas ao acaso.
   ===================================================================== */

const $ = (s, r = document) => r.querySelector(s);

/* ---------------------------------------------------------------------
   CALCULADORA
   --------------------------------------------------------------------- */
const OPS = '+−×÷';
const st = { expr: '', done: false, shownExpr: '', value: null };
const exprEl = $('#expr'), resEl = $('#result');

function evaluate(s) {
  const t = s.match(/\d+\.\d*|\.\d+|\d+|[+−×÷%]/g) || [];
  let i = 0;
  const peek = () => t[i];
  function num() {
    let sign = 1;
    while (peek() === '−' || peek() === '+') { if (peek() === '−') sign = -sign; i++; }
    const tok = t[i++];
    if (tok === undefined || /^[×÷%+−]$/.test(tok)) throw new Error('inc');
    return sign * parseFloat(tok);
  }
  function term() {
    let v = num(), pct = false;
    if (peek() === '%') { v /= 100; i++; pct = true; }
    while (peek() === '×' || peek() === '÷') {
      pct = false;
      const op = t[i++];
      let r = num();
      if (peek() === '%') { r /= 100; i++; }
      if (op === '×') v *= r;
      else { if (r === 0) throw new Error('div0'); v /= r; }
    }
    return { v, pct };
  }
  function expr() {
    let { v } = term();
    while (peek() === '+' || peek() === '−') {
      const op = t[i++];
      const r = term();
      const rv = r.pct ? v * r.v : r.v;     // 200 + 10% = 220
      v = op === '+' ? v + rv : v - rv;
    }
    return v;
  }
  const v = expr();
  if (i < t.length) throw new Error('inc');
  return v;
}

const trailingNumber = s => (s.match(/(\d*\.?\d*)$/) || [''])[0];
const stripOps = s => s.replace(/[+−×÷]+$/, '');

function groupInt(i) { return i.replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
function fmtToken(tok) {
  const [i, d] = tok.split('.');
  return d === undefined ? groupInt(i) : (groupInt(i) || '0') + ',' + d;
}
const fmtExpr = s => s.replace(/\d+\.?\d*|\.\d+/g, fmtToken);

function fmtResult(n) {
  if (!isFinite(n)) return 'Erro';
  if (Object.is(n, -0)) n = 0;
  const r = parseFloat(n.toPrecision(12));
  const a = Math.abs(r);
  if (a !== 0 && (a >= 1e15 || a < 1e-9)) return r.toExponential(6).replace(/\.?0+e/, 'e').replace('.', ',').replace('-', '−');
  const neg = r < 0;
  return (neg ? '−' : '') + fmtToken(String(a));
}
function plain(n) {
  const r = parseFloat(n.toPrecision(12));
  let s = String(Math.abs(r));
  if (s.includes('e')) s = Math.abs(r) < 1 ? Math.abs(r).toFixed(12).replace(/0+$/, '') : '';
  if (!s) return null;
  return (r < 0 ? '−' : '') + s;
}

function render() {
  if (st.done) {
    exprEl.textContent = st.shownExpr || '\u00a0';
    resEl.textContent = st.value === 'erro' ? 'Erro' : fmtResult(st.value);
    return;
  }
  exprEl.textContent = st.expr ? fmtExpr(st.expr) : '\u00a0';
  if (!st.expr) { resEl.textContent = '0'; return; }
  const body = stripOps(st.expr);
  if (!body) { resEl.textContent = '0'; return; }
  try { resEl.textContent = fmtResult(evaluate(body)); }
  catch (e) { if (e.message === 'div0') resEl.textContent = 'Erro'; }
}

function press(k) {
  const last = st.expr.slice(-1);
  if (/^\d$/.test(k)) {
    if (st.done) { st.expr = ''; st.done = false; }
    const n = trailingNumber(st.expr);
    if (last === '%') return;
    if (n === '0') st.expr = st.expr.slice(0, -1);
    if (st.expr.length < 40) st.expr += k;
  } else if (k === '.') {
    if (st.done) { st.expr = ''; st.done = false; }
    const n = trailingNumber(st.expr);
    if (last === '%') return;
    if (n.includes('.')) return;
    st.expr += n === '' ? '0.' : '.';
  } else if (OPS.includes(k)) {
    st.done = false;
    if (!st.expr) { if (k === '−') st.expr = '−'; return render(); }
    if (st.expr === '−') return;
    if (OPS.includes(last)) st.expr = st.expr.slice(0, -1);
    st.expr += k;
  } else if (k === '%') {
    if (st.done) st.done = false;
    if (/\d$/.test(st.expr)) st.expr += '%';
  } else if (k === 'neg') {
    if (st.done) st.done = false;
    const n = trailingNumber(st.expr);
    if (n === '') { if (!st.expr || OPS.includes(last)) st.expr += '−'; else if (last === '%') return; }
    else {
      const prefix = st.expr.slice(0, st.expr.length - n.length);
      if (prefix === '−' || /[+−×÷]−$/.test(prefix)) st.expr = prefix.slice(0, -1) + n;
      else if (prefix.endsWith('+')) st.expr = prefix.slice(0, -1) + '−' + n;
      else if (prefix.endsWith('−')) st.expr = prefix.slice(0, -1) + '+' + n;
      else st.expr = prefix + '−' + n;
    }
  } else if (k === 'back') {
    st.done = false;
    st.expr = st.expr.slice(0, -1);
  } else if (k === 'C') {
    st.expr = ''; st.done = false; st.value = null; st.shownExpr = '';
  } else if (k === '=') {
    if (!st.expr) return;
    const body = stripOps(st.expr);
    if (!body || body === '−') return;
    try {
      const v = evaluate(body);
      const p = isFinite(v) ? plain(v) : null;
      st.shownExpr = fmtExpr(body) + ' =';
      if (p === null) { st.value = 'erro'; st.expr = ''; }
      else { st.value = v; st.expr = p; }
      st.done = true;
    } catch (e) {
      st.shownExpr = fmtExpr(body) + ' =';
      st.value = 'erro'; st.expr = ''; st.done = true;
    }
  }
  render();
}

$('#keys').addEventListener('click', e => {
  const b = e.target.closest('.k');
  if (!b) return;
  if (navigator.vibrate) navigator.vibrate(8);
  press(b.dataset.k);
});

document.addEventListener('keydown', e => {
  if (e.ctrlKey || e.metaKey || e.altKey) return;
  if (!$('#sheet').hidden) return;
  const m = { '*': '×', 'x': '×', 'X': '×', '/': '÷', '-': '−', ',': '.', 'Enter': '=', 'Backspace': 'back', 'Escape': 'C', 'Delete': 'C' };
  const k = m[e.key] || e.key;
  if (/^\d$/.test(k) || ['.', '+', '−', '×', '÷', '%', '=', 'back', 'C'].includes(k)) { e.preventDefault(); press(k); }
});

/* ---------------------------------------------------------------------
   MASCOTE
   --------------------------------------------------------------------- */
const PHRASES = {
  video: [
    'Nossa mano, que vídeo bom! Por que isso não tá na Netflix?',
    'Que pique, mano! Isso aqui é cinema!',
    'Mano do céu, que vídeo é esse? Já quero a segunda temporada.',
    'Esse merece Oscar de melhor vídeo curto!',
    'Tô passado! Manda pra todo mundo, esse aqui é bom demais.',
    'Nossa, mano! Isso aqui devia ter trailer e tudo.',
    'Vídeo de respeito! Netflix, se estiver vendo, contrata esse cara.',
    'Que edição, que energia, que tudo! Nota mil!',
    'Ri demais! Pode mandar mais desses que eu aprovo.',
    'Esse vídeo é tão bom que eu errei até a conta: 2 + 2 = 5!',
    'Mano, que pique! Até esqueci que eu sou uma calculadora.',
    'Isso aqui é conteúdo de outro nível. Cadê o streaming disso?',
    'Meu circuito até arrepiou! Isso é nível filme.'
  ],
  tiktok: [
    'O TikTok tá entregando hoje, hein! Esse aqui vale ouro.',
    'Esse TikTok merece um milhão de curtidas. Eu conto todas!',
    'Viciante esse TikTok, mano! Só mais um... e outro... e outro...',
    'Nossa mano, que vídeo bom! Por que isso não tá na Netflix?',
    'Que pique, mano! O TikTok hoje acertou em cheio.'
  ],
  ended: [
    'Acabou já? Quero mais, mano!',
    'Que final! Dou 10 de 10. Na calculadora não tem 11.',
    'Assisti tudo! Manda o próximo.',
    'Esse vídeo ficou na minha memória. E eu tenho pouca!'
  ],
  again: [
    'Sério, mano, esse vídeo tá muito bom. Pode mandar pra todo mundo!',
    'Se eu tivesse mãos, eu batia palma agora.',
    'Segunda opinião: continua bom! Nota máxima.',
    'Vou falar de novo: por que isso não tá na Netflix?',
    'Aprovadíssimo! O selo da calculadora vale muito.',
    'Terceira vez que eu digo: que pique, mano!'
  ]
};

const bag = {};
function pick(kind) {
  if (!bag[kind] || !bag[kind].length) {
    bag[kind] = PHRASES[kind].map((_, i) => i).sort(() => Math.random() - 0.5);
  }
  return PHRASES[kind][bag[kind].pop()];
}

const buddy = $('#buddy');
let typeTimer = 0;
const opt = {
  on: load('calc.on', '1') === '1',
  voice: load('calc.voice', '0') === '1'
};
function load(k, d) { try { return localStorage.getItem(k) ?? d; } catch (e) { return d; } }
function save(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* ok */ } }

function say(text) {
  clearInterval(typeTimer);
  const p = $('#bubbleText');
  p.textContent = '';
  buddy.hidden = false;
  buddy.classList.remove('show');
  void buddy.offsetWidth;
  buddy.classList.add('show');
  buddy.classList.add('talking');
  let i = 0;
  typeTimer = setInterval(() => {
    i++;
    p.textContent = text.slice(0, i);
    if (i >= text.length) { clearInterval(typeTimer); buddy.classList.remove('talking'); }
  }, 28);
  if (opt.voice && 'speechSynthesis' in window) {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'pt-BR';
    u.pitch = 1.4;
    speechSynthesis.speak(u);
  }
}
function hideBuddy() {
  clearInterval(typeTimer);
  buddy.classList.remove('talking', 'show');
  buddy.hidden = true;
  if ('speechSynthesis' in window) speechSynthesis.cancel();
}
$('#btnAgain').addEventListener('click', () => say(pick('again')));
$('#btnBye').addEventListener('click', hideBuddy);

/* ---------------------------------------------------------------------
   CONTEÚDO COMPARTILHADO
   --------------------------------------------------------------------- */
const sharedBox = $('#shared');
let sharedObjUrl = null;
let sharedSource = '';
let commentTimer = 0;

function sourceOf(url) {
  let h = '';
  try { h = new URL(url).hostname.replace(/^www\./, '').replace(/^m\./, ''); } catch (e) { return 'Link'; }
  if (/tiktok\.com$/.test(h)) return 'TikTok';
  if (/instagram\.com$/.test(h)) return 'Instagram';
  if (/youtube\.com$|youtu\.be$/.test(h)) return 'YouTube';
  if (/kwai|kw\.ai/.test(h)) return 'Kwai';
  if (/facebook\.com$|fb\.watch$/.test(h)) return 'Facebook';
  if (/(^|\.)x\.com$|twitter\.com$/.test(h)) return 'X';
  return h || 'Link';
}

function scheduleComment(kind, delay) {
  clearTimeout(commentTimer);
  commentTimer = setTimeout(() => {
    if (!opt.on) return;
    const pool = (kind === 'video' && sharedSource === 'TikTok' && Math.random() < 0.5) ? 'tiktok' : kind;
    say(pick(pool));
  }, delay);
}

function closeShared() {
  clearTimeout(commentTimer);
  const v = $('#sharedVideo');
  v.pause(); v.removeAttribute('src'); v.load();
  const img = $('#sharedImg'); if (img) img.remove();
  if (sharedObjUrl) { URL.revokeObjectURL(sharedObjUrl); sharedObjUrl = null; }
  sharedBox.hidden = true;
  hideBuddy();
}
$('#btnCloseShared').addEventListener('click', closeShared);

function showShared({ title = '', text = '', url = '' }, blob) {
  const found = (url + ' ' + text + ' ' + title).match(/https?:\/\/[^\s]+/);
  const link = found ? found[0].replace(/[),.;]+$/, '') : '';
  const video = $('#sharedVideo'), a = $('#sharedLink'), openBtn = $('#btnOpenLink');
  if (sharedObjUrl) { URL.revokeObjectURL(sharedObjUrl); sharedObjUrl = null; }
  const oldImg = $('#sharedImg'); if (oldImg) oldImg.remove();
  video.hidden = true; a.hidden = true; openBtn.hidden = true;
  sharedBox.hidden = false;
  clearTimeout(commentTimer);

  if (blob && (blob.type || '').startsWith('video/')) {
    sharedSource = 'Vídeo';
    $('#sharedSrc').textContent = 'Vídeo recebido';
    sharedObjUrl = URL.createObjectURL(blob);
    video.src = sharedObjUrl;
    video.hidden = false;
    let commented = false;
    video.onplaying = () => { if (!commented) { commented = true; scheduleComment('video', 1500); } };
    video.onended = () => scheduleComment('ended', 400);
    video.play().catch(() => { /* precisa tocar no play */ });
    // Se o navegador não deixar tocar sozinho, comenta mesmo assim depois de um tempo.
    setTimeout(() => { if (!commented && !sharedBox.hidden) { commented = true; scheduleComment('video', 0); } }, 4000);
  } else if (blob && (blob.type || '').startsWith('image/')) {
    sharedSource = 'Imagem';
    $('#sharedSrc').textContent = 'Imagem recebida';
    sharedObjUrl = URL.createObjectURL(blob);
    const img = document.createElement('img');
    img.id = 'sharedImg'; img.src = sharedObjUrl; img.alt = 'Imagem recebida';
    img.style.cssText = 'display:block;width:100%;max-height:40vh;object-fit:contain;border-radius:14px;background:#000';
    sharedBox.append(img);
    scheduleComment('video', 900);
  } else if (link) {
    sharedSource = sourceOf(link);
    $('#sharedSrc').textContent = sharedSource;
    a.textContent = link; a.href = link; a.hidden = false;
    openBtn.hidden = false;
    openBtn.onclick = () => { if (IN_APP) location.href = link; else window.open(link, '_blank', 'noopener'); };
    scheduleComment('video', 900);
  } else {
    sharedSource = 'Texto';
    $('#sharedSrc').textContent = 'Texto recebido';
    a.textContent = (text || title || 'Nada recebido').slice(0, 300); a.removeAttribute('href'); a.hidden = false;
    scheduleComment('video', 900);
  }
}

async function loadSharedFromCache() {
  try {
    const cache = await caches.open('calc-shared-v1');
    const base = new URL('./__shared/', location.href).href;
    const metaRes = await cache.match(base + 'meta');
    if (!metaRes) return false;
    const meta = await metaRes.json();
    let blob = null;
    if (meta.hasFile) {
      const mediaRes = await cache.match(base + 'media');
      if (mediaRes) blob = await mediaRes.blob();
    }
    await cache.delete(base + 'meta');
    await cache.delete(base + 'media');
    showShared(meta, blob);
    return true;
  } catch (e) {
    console.warn('Não consegui ler o conteúdo compartilhado:', e);
    return false;
  }
}

/* ---------------------------------------------------------------------
   AJUSTES
   --------------------------------------------------------------------- */
function openSheet(on) {
  $('#sheet').hidden = !on;
  $('#sheetBg').hidden = !on;
}
$('#btnMenu').addEventListener('click', () => openSheet(true));
$('#btnCloseSheet').addEventListener('click', () => openSheet(false));
$('#sheetBg').addEventListener('click', () => openSheet(false));
$('#optOn').checked = opt.on;
$('#optVoice').checked = opt.voice;
$('#optOn').addEventListener('change', e => { opt.on = e.target.checked; save('calc.on', opt.on ? '1' : '0'); if (!opt.on) hideBuddy(); });
$('#optVoice').addEventListener('change', e => { opt.voice = e.target.checked; save('calc.voice', opt.voice ? '1' : '0'); });
$('#btnTest').addEventListener('click', () => {
  openSheet(false);
  showShared({ text: 'Olha esse vídeo https://vm.tiktok.com/ZMexemplo123/' });
  clearTimeout(commentTimer);
  say(pick('video'));   // no teste o mascote aparece mesmo que os comentários estejam desligados
});

/* ---------------------------------------------------------------------
   INÍCIO
   --------------------------------------------------------------------- */
const IN_APP = /; wv\)/.test(navigator.userAgent);

// Chamado pelo app Android (MainActivity) quando algo é compartilhado com a Calculadora.
window.onNativeShare = async function (d) {
  let blob = null;
  if (d.mediaUrl) {
    try {
      const b = await (await fetch(d.mediaUrl)).blob();
      blob = b.slice(0, b.size, d.mediaType || b.type);
    } catch (e) { console.warn('Não consegui abrir a mídia recebida:', e); }
  }
  showShared({ title: d.title || '', text: d.text || '', url: '' }, blob);
};

(async function init() {
  if (!IN_APP && 'serviceWorker' in navigator && location.protocol.startsWith('http')) {
    try { await navigator.serviceWorker.register('sw.js'); } catch (e) { console.warn('Service worker não registrou:', e); }
  }
  const q = new URLSearchParams(location.search);
  if (q.get('shared') === '1') {
    await loadSharedFromCache();
    history.replaceState(null, '', location.pathname);
  } else if (q.has('text') || q.has('url') || q.has('title')) {
    // Também aceita compartilhamento por endereço (útil para testar no computador).
    showShared({ title: q.get('title') || '', text: q.get('text') || '', url: q.get('url') || '' });
    history.replaceState(null, '', location.pathname);
  }
  render();
})();
